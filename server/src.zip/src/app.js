
const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { pool } = require("./db");

const app = express();

app.use(
  cors({
    origin: process.env.CLIENT_URL || "http://localhost:5173",
  })
);
app.use(express.json());

const TIME_SLOTS = [
  "Morning (fasting)",
  "After breakfast",
  "After lunch",
  "After dinner",
];

function getTodayIndia() {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
  }).format(new Date());
}

function validDate(date) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date || "")) return false;

  const parsed = new Date(`${date}T00:00:00Z`);

  return (
    !Number.isNaN(parsed.getTime()) &&
    parsed.toISOString().slice(0, 10) === date
  );
}

function auth(req, res, next) {
  const header = req.headers.authorization;
  const token = header?.startsWith("Bearer ")
    ? header.slice(7)
    : null;

  if (!token) {
    return res.status(401).json({ message: "Please log in." });
  }

  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    return res
      .status(401)
      .json({ message: "Invalid or expired session." });
  }
}

// REGISTER
app.post("/api/auth/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name?.trim() || !email?.trim() || !password) {
      return res.status(400).json({
        message: "Name, email and password are required.",
      });
    }

    if (password.length < 8) {
      return res.status(400).json({
        message: "Password must be at least 8 characters.",
      });
    }

    const normalizedEmail = email.trim().toLowerCase();

    const existing = await pool.query(
      "SELECT id FROM users WHERE email = $1",
      [normalizedEmail]
    );

    if (existing.rows.length) {
      return res.status(409).json({
        message: "Email is already registered.",
      });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    const result = await pool.query(
      `INSERT INTO users (name, email, password, password_hash)
       VALUES ($1, $2, $3, $4)
       RETURNING id, name, email`,
      [name.trim(), normalizedEmail, passwordHash, passwordHash]
    );

    res.status(201).json({
      message: "Registration successful.",
      user: result.rows[0],
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Registration failed." });
  }
});

// LOGIN
app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        message: "Email and password are required.",
      });
    }

    const result = await pool.query(
      "SELECT * FROM users WHERE email = $1",
      [email.trim().toLowerCase()]
    );

    const user = result.rows[0];

    if (
      !user ||
      !(await bcrypt.compare(
        password,
        user.password_hash || user.password
      ))
    ) {
      return res.status(401).json({
        message: "Invalid email or password.",
      });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: "1d" }
    );

    res.json({
      message: "Login successful.",
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Login failed." });
  }
});

// PROTECT READING AND REPORT ROUTES
app.use("/api/readings", auth);
app.use("/api/reports", auth);

// GET ALL READINGS
app.get("/api/readings", async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT
         id,
         reading_date,
         time_slot,
         value AS glucose_level
       FROM readings
       WHERE user_id = $1
       ORDER BY reading_date DESC, id DESC`,
      [req.user.id]
    );

    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Could not load readings." });
  }
});

// ADD READING
app.post("/api/readings", async (req, res) => {
  try {
    const { reading_date, time_slot, glucose_level } = req.body;
    const value = Number(glucose_level);

    if (!validDate(reading_date)) {
      return res.status(400).json({
        message: "Enter a valid date in YYYY-MM-DD format.",
      });
    }

    if (reading_date > getTodayIndia()) {
      return res.status(400).json({
        message: "Future dates are not allowed.",
      });
    }

    if (!TIME_SLOTS.includes(time_slot)) {
      return res.status(400).json({
        message: "Select a valid time slot.",
      });
    }

    if (!Number.isInteger(value) || value < 40 || value > 600) {
      return res.status(400).json({
        message: "Glucose level must be between 40 and 600 mg/dL.",
      });
    }

    const count = await pool.query(
      `SELECT COUNT(*)::int AS total
       FROM readings
       WHERE user_id = $1 AND reading_date = $2`,
      [req.user.id, reading_date]
    );

    if (count.rows[0].total >= 4) {
      return res.status(400).json({
        message: "You can add a maximum of four readings per day.",
      });
    }

    const result = await pool.query(
      `INSERT INTO readings
         (user_id, reading_date, time_slot, value)
       VALUES ($1, $2, $3, $4)
       RETURNING id, reading_date, time_slot,
                 value AS glucose_level`,
      [req.user.id, reading_date, time_slot, value]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    if (error.code === "23505") {
      return res.status(409).json({
        message: "A reading already exists for this date and time slot.",
      });
    }

    console.error(error);
    res.status(500).json({ message: "Could not save reading." });
  }
});

// UPDATE READING
app.put("/api/readings/:id", async (req, res) => {
  try {
    const { reading_date, time_slot, glucose_level } = req.body;
    const value = Number(glucose_level);

    if (!validDate(reading_date) || reading_date > getTodayIndia()) {
      return res.status(400).json({
        message: "Enter a valid date that is not in the future.",
      });
    }

    if (!TIME_SLOTS.includes(time_slot)) {
      return res.status(400).json({
        message: "Select a valid time slot.",
      });
    }

    if (!Number.isInteger(value) || value < 40 || value > 600) {
      return res.status(400).json({
        message: "Glucose level must be between 40 and 600 mg/dL.",
      });
    }

    const result = await pool.query(
      `UPDATE readings
       SET reading_date = $1,
           time_slot = $2,
           value = $3
       WHERE id = $4 AND user_id = $5
       RETURNING id, reading_date, time_slot,
                 value AS glucose_level`,
      [reading_date, time_slot, value, req.params.id, req.user.id]
    );

    if (!result.rows.length) {
      return res.status(404).json({
        message: "Reading not found.",
      });
    }

    res.json(result.rows[0]);
  } catch (error) {
    if (error.code === "23505") {
      return res.status(409).json({
        message: "A reading already exists for this date and time slot.",
      });
    }

    console.error(error);
    res.status(500).json({ message: "Could not update reading." });
  }
});

// DELETE READING
app.delete("/api/readings/:id", async (req, res) => {
  try {
    const result = await pool.query(
      `DELETE FROM readings
       WHERE id = $1 AND user_id = $2
       RETURNING id`,
      [req.params.id, req.user.id]
    );

    if (!result.rows.length) {
      return res.status(404).json({
        message: "Reading not found.",
      });
    }

    res.json({ message: "Reading deleted successfully." });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Could not delete reading." });
  }
});

// REPORTS
app.get("/api/reports", async (req, res) => {
  try {
    const date = req.query.date || getTodayIndia();

    if (!validDate(date) || date > getTodayIndia()) {
      return res.status(400).json({
        message: "Enter a valid report date.",
      });
    }

    const monthStart = `${date.slice(0, 7)}-01`;

    const previousMonthDate = new Date(`${monthStart}T00:00:00Z`);
    previousMonthDate.setUTCMonth(
      previousMonthDate.getUTCMonth() - 1
    );

    const previousStart = previousMonthDate
      .toISOString()
      .slice(0, 10);

    const previousEnd = monthStart;

    const [daily, monthToDate, previousMonth] = await Promise.all([
      pool.query(
        `SELECT
           COUNT(*)::int AS count,
           MIN(value)::int AS min,
           MAX(value)::int AS max,
           ROUND(AVG(value), 1) AS average
         FROM readings
         WHERE user_id = $1 AND reading_date = $2`,
        [req.user.id, date]
      ),

      pool.query(
        `SELECT
           COUNT(*)::int AS count,
           MIN(value)::int AS min,
           MAX(value)::int AS max,
           ROUND(AVG(value), 1) AS average
         FROM readings
         WHERE user_id = $1
           AND reading_date >= $2
           AND reading_date <= $3`,
        [req.user.id, monthStart, date]
      ),

      pool.query(
        `SELECT
           COUNT(*)::int AS count,
           MIN(value)::int AS min,
           MAX(value)::int AS max,
           ROUND(AVG(value), 1) AS average
         FROM readings
         WHERE user_id = $1
           AND reading_date >= $2
           AND reading_date < $3`,
        [req.user.id, previousStart, previousEnd]
      ),
    ]);

    res.json({
      selectedDate: date,
      daily: daily.rows[0],
      monthToDate: monthToDate.rows[0],
      previousMonth: previousMonth.rows[0],
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      message: "Could not generate reports.",
    });
  }
});

// HEALTH CHECK
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    message: "Sweety API is running.",
  });
});

module.exports = app;
