
import { useEffect, useState } from "react";
import axios from "axios";
import "./App.css";

const API = "http://localhost:5000/api";

const slots = [
  "Morning (fasting)",
  "After breakfast",
  "After lunch",
  "After dinner",
];

const today = () => {
  const d = new Date();
  const local = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
};

function App() {
  const [token, setToken] = useState(localStorage.getItem("token") || "");
  const [user, setUser] = useState(
    JSON.parse(localStorage.getItem("user") || "null")
  );
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
  });
  const [reading, setReading] = useState({
    reading_date: today(),
    time_slot: slots[0],
    glucose_level: "",
  });
  const [readings, setReadings] = useState([]);
  const [reports, setReports] = useState(null);
  const [reportDate, setReportDate] = useState(today());
  const [editingId, setEditingId] = useState(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const headers = { Authorization: `Bearer ${token}` };

  function notify(text, isError = false) {
    setMessage(isError ? "" : text);
    setError(isError ? text : "");
  }

  async function submitAuth(e) {
    e.preventDefault();
    setLoading(true);
    notify("");

    try {
      const endpoint = mode === "login" ? "login" : "register";
      const result = await axios.post(`${API}/auth/${endpoint}`, form);

      if (mode === "register") {
        notify("Account created! Please log in.");
        setMode("login");
      } else {
        localStorage.setItem("token", result.data.token);
        localStorage.setItem("user", JSON.stringify(result.data.user));
        setToken(result.data.token);
        setUser(result.data.user);
        notify("Welcome to Sweety!");
      }
    } catch (err) {
      notify(err.response?.data?.message || "Authentication failed.", true);
    } finally {
      setLoading(false);
    }
  }

  async function loadData(currentToken = token, date = reportDate) {
    try {
      const config = { headers: { Authorization: `Bearer ${currentToken}` } };
      const [r, report] = await Promise.all([
        axios.get(`${API}/readings`, config),
        axios.get(`${API}/reports?date=${date}`, config),
      ]);
      setReadings(r.data);
      setReports(report.data);
    } catch (err) {
      if (err.response?.status === 401) logout();
      else notify("Unable to load your data.", true);
    }
  }

  useEffect(() => {
    if (token) loadData(token);
  }, [token]);

  async function saveReading(e) {
    e.preventDefault();
    notify("");

    const value = Number(reading.glucose_level);
    if (!Number.isInteger(value) || value < 40 || value > 600) {
      notify("Enter a whole glucose value between 40 and 600 mg/dL.", true);
      return;
    }

    try {
      const config = { headers };
      if (editingId) {
        await axios.put(`${API}/readings/${editingId}`, reading, config);
        notify("Reading updated successfully.");
      } else {
        await axios.post(`${API}/readings`, reading, config);
        notify("Reading saved successfully.");
      }

      setEditingId(null);
      setReading({
        reading_date: today(),
        time_slot: slots[0],
        glucose_level: "",
      });
      await loadData();
    } catch (err) {
      notify(err.response?.data?.message || "Could not save reading.", true);
    }
  }

  function editReading(item) {
    setEditingId(item.id);
    setReading({
      reading_date: String(item.reading_date).slice(0, 10),
      time_slot: item.time_slot,
      glucose_level: item.glucose_level,
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function deleteReading(id) {
    if (!window.confirm("Delete this glucose reading?")) return;

    try {
      await axios.delete(`${API}/readings/${id}`, { headers });
      notify("Reading deleted.");
      await loadData();
    } catch (err) {
      notify(err.response?.data?.message || "Delete failed.", true);
    }
  }

  async function changeReportDate(date) {
    setReportDate(date);
    try {
      const result = await axios.get(
        `${API}/reports?date=${date}`,
        { headers }
      );
      setReports(result.data);
    } catch {
      notify("Unable to load report.", true);
    }
  }

  function logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setToken("");
    setUser(null);
    setReadings([]);
    setReports(null);
  }

  if (!token) {
    return (
      <main className="auth-page">
        <section className="auth-card">
          <div className="brand-icon">♥</div>
          <h1>Sweety</h1>
          <p className="muted">Your personal blood glucose companion</p>
          <h2>{mode === "login" ? "Welcome back" : "Create your account"}</h2>

          <form onSubmit={submitAuth}>
            {mode === "register" && (
              <input
                placeholder="Full name"
                value={form.name}
                onChange={e => setForm({ ...form, name: e.target.value })}
                required
              />
            )}
            <input
              type="email"
              placeholder="Email address"
              value={form.email}
              onChange={e => setForm({ ...form, email: e.target.value })}
              required
            />
            <input
              type="password"
              placeholder="Password (minimum 8 characters)"
              value={form.password}
              onChange={e => setForm({ ...form, password: e.target.value })}
              minLength={8}
              required
            />
            <button disabled={loading}>
              {loading ? "Please wait..." : mode === "login" ? "Login" : "Register"}
            </button>
          </form>

          {message && <p className="success">{message}</p>}
          {error && <p className="error">{error}</p>}

          <p className="switch">
            {mode === "login" ? "New to Sweety?" : "Already registered?"}
            <button className="link" onClick={() => {
              setMode(mode === "login" ? "register" : "login");
              notify("");
            }}>
              {mode === "login" ? " Create account" : " Login"}
            </button>
          </p>
        </section>
      </main>
    );
  }

  const average = reports?.daily?.average;

  return (
    <main className="dashboard">
      <header className="topbar">
        <div>
          <h1>♥ Sweety</h1>
          <p>Your glucose health dashboard</p>
        </div>
        <div className="profile">
          <span>Hello, {user?.name || "User"}</span>
          <button className="secondary" onClick={logout}>Logout</button>
        </div>
      </header>

      {message && <p className="success notice">{message}</p>}
      {error && <p className="error notice">{error}</p>}

      <section className="welcome">
        <div>
          <h2>Welcome back, {user?.name || "User"}!</h2>
          <p>Keep track of your daily glucose readings.</p>
        </div>
        <span className="today">{today()}</span>
      </section>

      <section className="stats">
        <Stat title="Today's readings" value={reports?.daily?.count ?? 0} />
        <Stat title="Daily average" value={average == null ? "--" : `${average} mg/dL`} />
        <Stat title="Minimum" value={reports?.daily?.min ?? "--"} />
        <Stat title="Maximum" value={reports?.daily?.max ?? "--"} />
      </section>

      <section className="panel">
        <h2>{editingId ? "Update reading" : "Add glucose reading"}</h2>
        <form className="reading-form" onSubmit={saveReading}>
          <label>
            Date
            <input
              type="date"
              value={reading.reading_date}
              max={today()}
              onChange={e => setReading({ ...reading, reading_date: e.target.value })}
              required
            />
          </label>
          <label>
            Time slot
            <select
              value={reading.time_slot}
              onChange={e => setReading({ ...reading, time_slot: e.target.value })}
            >
              {slots.map(slot => <option key={slot}>{slot}</option>)}
            </select>
          </label>
          <label>
            Glucose level (mg/dL)
            <input
              type="number"
              min="40"
              max="600"
              step="1"
              placeholder="e.g. 110"
              value={reading.glucose_level}
              onChange={e => setReading({ ...reading, glucose_level: e.target.value })}
              required
            />
          </label>
          <button type="submit">{editingId ? "Update reading" : "Save reading"}</button>
          {editingId && (
            <button type="button" className="secondary" onClick={() => {
              setEditingId(null);
              setReading({ reading_date: today(), time_slot: slots[0], glucose_level: "" });
            }}>
              Cancel
            </button>
          )}
        </form>
      </section>

      <section className="panel">
        <h2>Glucose history</h2>
        {readings.length === 0 ? (
          <p className="muted">No readings yet. Add your first reading above.</p>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Date</th><th>Time slot</th><th>Glucose</th><th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {readings.map(item => (
                  <tr key={item.id}>
                    <td>{String(item.reading_date).slice(0, 10)}</td>
                    <td>{item.time_slot}</td>
                    <td>{item.glucose_level} mg/dL</td>
                    <td className="actions">
                      <button className="small secondary" onClick={() => editReading(item)}>Edit</button>
                      <button className="small danger" onClick={() => deleteReading(item.id)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <section className="panel">
        <h2>Glucose reports</h2>
        <label className="report-date">
          Select report date
          <input type="date" value={reportDate} max={today()}
            onChange={e => changeReportDate(e.target.value)} />
        </label>
        <div className="report-grid">
          <Report title="Daily report" data={reports?.daily} />
          <Report title="Month to date" data={reports?.monthToDate} />
          <Report title="Previous month" data={reports?.previousMonth} />
        </div>
      </section>

      <footer>Sweety · Blood Glucose Tracker</footer>
    </main>
  );
}

function Stat({ title, value }) {
  return <div className="stat-card"><p>{title}</p><strong>{value}</strong></div>;
}

function Report({ title, data }) {
  return (
    <div className="report-card">
      <h3>{title}</h3>
      <p>Readings: <strong>{data?.count ?? 0}</strong></p>
      <p>Minimum: <strong>{data?.min ?? "--"}</strong></p>
      <p>Maximum: <strong>{data?.max ?? "--"}</strong></p>
      <p>Average: <strong>{data?.average ?? "--"}</strong></p>
    </div>
  );
}

export default App;
